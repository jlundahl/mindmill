from setuptools import setup, find_packages

setup(
    name="ontology_pipeline",
    version="0.1.0",
    description="Modular ingestion and ontology building pipeline",
    packages=find_packages(),
    install_requires=[
        "pyyaml>=5.1",
    ],
    entry_points={
        "console_scripts": [
            "ontology-pipeline=ontology_pipeline.main:main",
        ],
    },
    python_requires=">=3.8",
)