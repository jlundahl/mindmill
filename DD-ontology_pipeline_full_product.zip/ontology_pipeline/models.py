"""
Data models used throughout the ontology pipeline.

These classes primarily serve as containers for structured data during
extraction and ontology construction.  They are kept intentionally
lightweight; more fields can be added as needed for a particular domain.
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ExperienceUnit:
    """A basic unit of experience extracted from raw corpora.

    An ExperienceUnit (XU) encapsulates all information about a single
    actionable event or observation.  It captures the state before the
    action, the action itself and its parameters, any measurable
    outcomes, a release condition, and miscellaneous metadata such as
    notes or media references.
    """

    id: str
    #: Unique identifier for this unit

    actors: List[str] = field(default_factory=list)
    #: Actors (people, systems) involved in this unit

    setup_state: str = ""
    #: Identifier for the starting state prior to the action

    action: str = ""
    #: Identifier for the action performed

    params: Dict[str, Any] = field(default_factory=dict)
    #: Parameters associated with the action

    observables: Dict[str, Any] = field(default_factory=dict)
    #: Observations captured after the action

    release_test: str = ""
    #: Condition under which the unit is considered successful

    notes: str = ""
    #: Freeform description or commentary about the event

    media: List[str] = field(default_factory=list)
    #: References to associated media (audio/video clips, images)

    timestamp: Optional[str] = None
    #: Optional timestamp if known (ISO format)

    source: Optional[str] = None
    #: Optional name of the source file or context for this unit.  Allows
    #: context and governance layers to associate experience units with
    #: their origin.  Defined once to avoid duplicate field bug.


@dataclass
class Ontology:
    """Container for the complete ontology.

    The ontology is represented as a dictionary keyed by layer names.  Each
    layer may contain arbitrary nested structures.  The builder functions
    should populate these structures consistently so that downstream
    consumers can traverse and interpret them.
    """
    layers: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Return the underlying dictionary representing the ontology."""
        return self.layers
