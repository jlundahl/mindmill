"""
Ontology orchestration module.

The :class:`OntologyBuilder` coordinates the construction of all layers in
the ontology.  It accepts a list of ExperienceUnits and iteratively applies
each layer's build function, producing a nested dictionary that fully
describes the knowledge extracted from the corpus.  Existing ontologies can
be merged with new data for incremental updates.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from .models import ExperienceUnit, Ontology
from .layers import load_layers


class OntologyBuilder:
    """Constructs a multi‑layer ontology from experience units.

    Parameters
    ----------
    layers : Optional[List]
        Custom list of layer modules.  If None, the default layers are
        loaded from :func:`ontology_pipeline.layers.get_layer_modules`.
    """

    def __init__(self, layers: Optional[List] = None) -> None:
        self.layers = layers or load_layers()

    def build(self, xus: List[ExperienceUnit], existing: Optional[Ontology] = None) -> Ontology:
        """Construct an ontology from a list of experience units.

        Parameters
        ----------
        xus : List[ExperienceUnit]
            Experience units extracted from the corpus.
        existing : Optional[Ontology]
            An existing ontology to merge with.  The new ontology will
            incorporate data from both sources.  Conflicts will be resolved
            naively by overwriting existing fields; for more sophisticated
            merging you may implement custom logic here.

        Returns
        -------
        Ontology
            The fully constructed ontology.
        """
        ontology_dict: Dict[str, Any] = existing.to_dict() if existing else {}
        # Apply each layer sequentially
        for layer in self.layers:
            build_fn = getattr(layer, "build", None)
            if callable(build_fn):
                ontology_dict = build_fn(xus, ontology_dict)
        return Ontology(layers=ontology_dict)
