"""
Ingestion module for the ontology pipeline.

This module provides functions for reading unstructured corpora from disk and
emitting a sequence of :class:`~ontology_pipeline.models.ExperienceUnit` objects.
The extraction logic here is intentionally simple: each non‑blank line in a
plain text file is treated as a distinct experience.  Domain experts can
extend or replace these functions with NLP or computer vision to extract
actions, parameters, observations and latent cues.
"""

from __future__ import annotations

import os
from typing import List, Optional
from .models import ExperienceUnit
from .utils import generate_id, read_text_files


def ingest_directory(input_dir: str) -> List[ExperienceUnit]:
    """Ingest all text files in a directory into ExperienceUnits.

    This improved ingestion process groups lines into chunks based on blank
    lines and timestamp patterns, and attempts to extract a timestamp and
    meaningful action slug from each chunk.  It produces a list of
    ExperienceUnit objects ready for further processing.  In addition to
    the notes and derived slug, the ingestion now records the name of
    the source file from which each unit was extracted.  This field is
    stored on the ``source`` attribute of the ExperienceUnit and can be
    leveraged by contextual, governance and narrative layers.  The ID for
    each unit is derived from its position in the corpus.

    Parameters
    ----------
    input_dir : str
        Root directory containing `.txt` files.  Files are read recursively.

    Returns
    -------
    List[ExperienceUnit]
        A list of extracted experience units.  Each unit may consist of one
        or more lines of text grouped by simple heuristics.
    """
    import re
    units: List[ExperienceUnit] = []
    counter = 0
    timestamp_re = re.compile(r"\b(\d{1,2}:\d{2}(?::\d{2})?)\b")

    # Default source name used by flush_buffer; updated per file in the loop below
    source_name: str = ""

    def slugify(text: str, max_words: int = 5) -> str:
        """Create a slug from the first few words of a string.

        Normalises punctuation and whitespace and lowercases each word.
        """
        import string
        words = [w.strip(string.punctuation).lower() for w in text.split()[:max_words]]
        return "_".join(filter(None, words))

    def extract_actors(line: str) -> List[str]:
        """Extract actor names or roles from a line of text.

        This heuristic looks for role descriptors such as 'Trainer',
        'Coach', 'Student', 'Rider', etc., followed by a capitalised
        name.  It also captures standalone capitalised names at the
        beginning of a sentence.  Returns a list of strings, one per
        actor detected.
        """
        import re
        # Patterns to match role+name or single capitalised name
        patterns = [
            r"\b(Trainer|Coach|Student|Rider|Judge|Veterinarian)\s+([A-Z][a-z]+)\b",
            r"\b([A-Z][a-z]+\s[A-Z][a-z]+)\b",  # two capitalised words
            r"^([A-Z][a-z]+)\b",  # single capitalised word at start
        ]
        actors: List[str] = []
        for pat in patterns:
            for match in re.finditer(pat, line):
                # join groups if multiple
                groups = match.groups()
                if groups:
                    actor = " ".join([g for g in groups if g])
                    if actor and actor not in actors:
                        actors.append(actor)
        return actors

    def extract_measurements(text: str) -> Dict[str, Any]:
        """Extract numeric measurements from freeform text.

        Recognises common time, distance, angle, weight, temperature and
        percentage units.  Returns a dictionary keyed by the unit type
        with the numeric value and original unit string.  If multiple
        measurements of the same type appear, only the first is kept.
        """
        import re
        measurements: Dict[str, Any] = {}
        pattern = re.compile(
            r"(\d+(?:\.\d+)?)(?:\s*)(seconds?|mins?|minutes?|hours?|hrs?|h|feet|ft|meters?|m|km|kilometers?|miles?|mph|kph|km/h|kg|kilograms?|lbs?|pounds?|degrees?|deg|°|°f|°c|%|bpm)",
            re.IGNORECASE,
        )
        for value, unit in pattern.findall(text):
            try:
                val = float(value)
            except Exception:
                continue
            unit_lower = unit.lower()
            # Map unit to a canonical key
            key = None
            if unit_lower in {"seconds", "second", "sec", "s"}:
                key = "time_seconds"
            elif unit_lower in {"minutes", "minute", "mins", "min", "m"}:
                key = "time_minutes"
            elif unit_lower in {"hours", "hour", "hrs", "h"}:
                key = "time_hours"
            elif unit_lower in {"ft", "feet"}:
                key = "distance_ft"
            elif unit_lower in {"meter", "meters", "m"}:
                key = "distance_m"
            elif unit_lower in {"km", "kilometers", "kilometer", "km/h", "kph"}:
                key = "speed_kph"
            elif unit_lower in {"mph"}:
                key = "speed_mph"
            elif unit_lower in {"kg", "kilograms", "kilogram"}:
                key = "weight_kg"
            elif unit_lower in {"lb", "lbs", "pounds", "pound"}:
                key = "weight_lb"
            elif unit_lower in {"degrees", "degree", "deg", "°", "°f", "°c"}:
                key = "angle_deg"
            elif unit_lower == "%":
                key = "percentage"
            elif unit_lower == "bpm":
                key = "heart_rate_bpm"
            else:
                # Unknown unit – use as raw unit key
                key = unit_lower
            if key and key not in measurements:
                measurements[key] = {"value": val, "unit": unit_lower}
        return measurements

    def flush_buffer(buf: List[str], ts: Optional[str]) -> None:
        """Create an ExperienceUnit from the buffered lines and timestamp."""
        nonlocal counter
        if not buf:
            return
        xu_id = generate_id("xu_", counter)
        counter += 1
        notes = " ".join(buf).strip()
        # Derive a simple action slug based on the start of the notes
        slug = slugify(notes)
        action_id = f"A.{slug or xu_id}_action"
        # Extract actors and measurements from the notes
        actors = extract_actors(notes)
        observables = extract_measurements(notes)
        unit = ExperienceUnit(
            id=xu_id,
            source=source_name,
            actors=actors,
            setup_state=f"S.{xu_id}_pre",
            action=action_id,
            params={},
            observables=observables,
            release_test="",
            notes=notes,
            media=[],
            timestamp=ts,
        )
        units.append(unit)

    import os
    for path, text in read_text_files(input_dir):
        buffer: List[str] = []
        current_ts: Optional[str] = None
        # Set source_name based on file name for this segment
        source_name = os.path.basename(path)
        for line in text.splitlines():
            stripped = line.strip()
            # Detect blank lines as boundaries
            if not stripped:
                flush_buffer(buffer, current_ts)
                buffer = []
                current_ts = None
                continue
            # Detect timestamps at the beginning of a line
            ts_match = timestamp_re.match(stripped)
            if ts_match:
                # Flush buffer before starting a new timestamped segment
                flush_buffer(buffer, current_ts)
                buffer = []
                current_ts = ts_match.group(1)
                # Remove the timestamp from the line for notes
                remainder = stripped[ts_match.end():].lstrip()
                if remainder:
                    buffer.append(remainder)
                continue
            buffer.append(stripped)
        # Flush any remaining buffer at EOF
        flush_buffer(buffer, current_ts)
        buffer = []
        current_ts = None
    return units
