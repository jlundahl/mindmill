"""
Kinetic layer builder.

This layer interprets each experience unit as a transition from a pre‑state to
a post‑state via an action.  Unlike the simplistic implementation, this
version derives the structure of states and actions from the content of
each unit.  Actions are defined by a verb–object pair extracted from
the notes.  States are hashed from the set of semantic entities present
in the notes and the originating context (e.g. source file), so that
identical contexts and entity sets share state nodes.  Edges include
a proof reference to the originating experience unit.  This produces a
more realistic kinetic graph where similar situations map to the same
state.
"""

from typing import Dict, List, Any
import hashlib
import re
from ..models import ExperienceUnit


def _action_slug(notes: str) -> tuple[str, str]:
    """Extract a verb–object slug from a note string.

    Uses a simple regex to find the first occurrence of a verb followed
    by an optional determiner and a noun.  If no such pattern is
    found, a generic ("do", "thing") slug is returned.

    Parameters
    ----------
    notes : str
        The free‑form description of the experience.

    Returns
    -------
    tuple[str, str]
        A pair ``(verb, object)`` representing the action.
    """
    m = re.search(r"\b([A-Za-z]+)\s+(?:the|a|an)?\s*([A-Za-z_]+)\b", notes)
    if m:
        return (m.group(1).lower(), m.group(2).lower())
    return ("do", "thing")


def _state_hash(entities: List[str], context: str) -> str:
    """Compute a deterministic hash for a state.

    The hash is derived from the sorted list of entity identifiers and
    the context.  This ensures that two states with the same set of
    entities and context share the same identifier.

    Parameters
    ----------
    entities : List[str]
        Sorted list of semantic entity identifiers present in the note.
    context : str
        The context identifier (e.g. source file name).

    Returns
    -------
    str
        A unique state identifier.
    """
    sig = "|".join(entities) + "|" + context
    return "S." + hashlib.md5(sig.encode()).hexdigest()[:10]


def build(xus: List[ExperienceUnit], ontology: Dict[str, Any]) -> Dict[str, Any]:
    """Populate the kinetic layer of the ontology.

    Parameters
    ----------
    xus : List[ExperienceUnit]
        Ordered list of experience units.
    ontology : Dict[str, Any]
        Partially built ontology that already contains at least the
        semantic layer.

    Returns
    -------
    Dict[str, Any]
        The updated ontology dictionary with a kinetic layer added.
    """
    states: Dict[str, Dict[str, Any]] = {}
    actions: Dict[str, Dict[str, Any]] = {}
    edges: List[Dict[str, Any]] = []

    # Load semantic entities if available
    semantic_entities = ontology.get("semantic", {}).get("entities", {})
    # Build a mapping of entity name to ID for quick lookup
    name_to_id = {v["name"]: k for k, v in semantic_entities.items()}

    for xu in xus:
        # Determine the set of semantic entities mentioned in the note
        noted_entities: List[str] = []
        note_lower = xu.notes.lower()
        for name, ent_id in name_to_id.items():
            # Skip single character names to avoid false positives
            if len(name) < 2:
                continue
            if name in note_lower:
                noted_entities.append(ent_id)
        noted_entities.sort()
        # Determine context from source file
        context_id = (xu.source or "unknown").lower()
        # Compute pre‑state identifier
        s_pre = _state_hash(noted_entities, context_id)
        s_post = s_pre + "_post"
        # Extract action verb and object
        verb, obj = _action_slug(xu.notes)
        a_id = f"A.{verb}_{obj}"
        # Record states with minimal attributes
        if s_pre not in states:
            states[s_pre] = {"id": s_pre, "attrs": {"context": context_id}}
        if s_post not in states:
            states[s_post] = {"id": s_post, "attrs": {"context": context_id}}
        # Record action with examples
        if a_id not in actions:
            actions[a_id] = {"id": a_id, "verb": verb, "object": obj, "examples": []}
        actions[a_id]["examples"].append(xu.id)
        # Record kinetic edge
        edges.append({
            "id": f"Edge.{xu.id}",
            "from": s_pre,
            "action": a_id,
            "to": s_post,
            "proof": {"xu_refs": [xu.id]},
        })
    ontology["kinetic"] = {
        "states": list(states.values()),
        "actions": list(actions.values()),
        "edges": edges,
    }
    return ontology
