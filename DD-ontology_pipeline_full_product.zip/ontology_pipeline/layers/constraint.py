"""
Constraint layer builder.

This layer defines the boundaries and safety conditions associated with the
domain.  In this simplified implementation we derive constraints from simple
statistics over the notes length, flagging unusually long or short lines.
In a real deployment, constraints would be read from manuals, regulatory
documents or domain knowledge.
"""

from typing import Dict, List, Any
from ..models import ExperienceUnit


def build(xus: List[ExperienceUnit], ontology: Dict[str, Any]) -> Dict[str, Any]:
    """Populate the constraint layer.

    Extracts explicit constraint statements from notes.  Phrases such as
    "must", "must not", "should", "never", and "avoid" are interpreted
    as hard, soft or preference constraints.  The output is a list of
    constraints with their types and textual descriptions.
    """
    import re
    constraints: List[Dict[str, Any]] = []
    pattern = re.compile(r"\b(must not|must|should not|should|never|always|avoid|do not)\b", re.IGNORECASE)
    for xu in xus:
        for match in pattern.finditer(xu.notes):
            phrase = match.group(1).lower()
            # Determine type based on phrase
            if phrase in {"must not", "never", "do not"}:
                ctype = "hard"
            elif phrase in {"must", "always"}:
                ctype = "mandatory"
            elif phrase in {"should not", "avoid"}:
                ctype = "soft"
            else:
                ctype = "recommendation"
            # Extract the rest of the sentence as the condition
            condition = xu.notes[match.end():].strip()
            constraints.append({
                "type": ctype,
                "phrase": phrase,
                "condition": condition,
                "xu_id": xu.id,
            })
    ontology["constraint"] = {
        "list": constraints,
    }
    return ontology
