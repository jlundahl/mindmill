"""
Conflict detection layer.

This layer inspects the corpus and existing ontology to find
contradictions or inconsistencies.  Conflicts may arise when the same
action is described with opposite polarity (e.g. "do X" versus
"avoid X"), when antonymic actions are both present in the kinetic
layer, or when parameter values vary widely for the same action.  The
resulting list of issues helps users identify areas where further
clarification or evidence is needed.
"""

from __future__ import annotations

from typing import Dict, List, Any
import re
import statistics
from ..models import ExperienceUnit


# Mapping of verbs to their antonyms for conflict detection
ANTONYMS = {
    "increase": "decrease",
    "open": "close",
    "tighten": "loosen",
    "pull": "push",
    "raise": "lower",
    "expand": "contract",
}


def build(xus: List[ExperienceUnit], ontology: Dict[str, Any]) -> Dict[str, Any]:
    """Populate the conflict layer of the ontology.

    Scans notes and the kinetic layer to detect different categories of
    conflict:

    - **Polarity conflicts** where an instruction both encourages and
      discourages the same action (e.g. "do X" and "do not X" in the
      same note).
    - **Antonym conflicts** where both a verb and its antonym appear as
      separate actions in the kinetic layer (e.g. "open" and "close").
    - **Parameter variance** where numeric parameters for the same
      concept vary widely across the corpus (e.g. "turns: 2" vs "turns: 6").

    The conflicts are returned in a list of issue dictionaries attached
    to the ontology.  Each entry includes the conflict type and any
    relevant metadata.
    """
    issues: List[Dict[str, Any]] = []
    # Detect polarity conflicts within individual notes
    for xu in xus:
        text = xu.notes.lower()
        # Look for explicit instructions to do something
        m_do = re.search(r"\b(do|use|apply|perform)\s+([a-z]+)\b", text)
        # Look for explicit instructions to avoid the same thing
        m_dont = re.search(r"\b(avoid|do\s+not|never)\s+([a-z]+)\b", text)
        if m_do and m_dont and m_do.group(2) == m_dont.group(2):
            issues.append({
                "type": "polarity",
                "action": m_do.group(2),
                "xu": xu.id,
                "description": f"Conflicting instructions to do and not do '{m_do.group(2)}' in the same note",
            })
    # Detect antonym conflicts across the kinetic actions
    kinetic_actions = ontology.get("kinetic", {}).get("actions", [])
    verbs = set()
    for action in kinetic_actions:
        if isinstance(action, dict):
            verb = action.get("verb")
            if verb:
                verbs.add(verb.lower())
    for w, opp in ANTONYMS.items():
        if w in verbs and opp in verbs:
            issues.append({
                "type": "antonym",
                "verb": w,
                "opposite": opp,
                "description": f"Actions with opposite meanings ('{w}' vs '{opp}') are present",
            })
    # Detect high variance in numeric parameters (e.g. turns)
    param_values: Dict[str, List[int]] = {}
    for xu in xus:
        m = re.search(r"\b(turns?)\s*:?\s*(\d+)", xu.notes, re.I)
        if m:
            param = m.group(1).lower()
            val = int(m.group(2))
            param_values.setdefault(param, []).append(val)
    for param, vals in param_values.items():
        if len(vals) > 1:
            stdev = statistics.pstdev(vals)
            if stdev > 1:
                issues.append({
                    "type": "param_variance",
                    "param": param,
                    "stdev": stdev,
                    "description": f"High variance in numeric parameter '{param}' (stdev={stdev:.2f})",
                })
    ontology["conflict"] = {
        "issues": issues,
    }
    return ontology