"""
Metric layer builder.

The metric layer extracts quantitative features from each experience unit.  In
the absence of structured observables, the default implementation records
basic statistics such as the length of the notes and counts of actions.  In
a production system this layer would handle sensor data, telemetry or other
continuous signals.
"""

from typing import Dict, List, Any
from statistics import mean, stdev
from ..models import ExperienceUnit


def build(xus: List[ExperienceUnit], ontology: Dict[str, Any]) -> Dict[str, Any]:
    """Populate the metric layer.

    Extracts quantitative measurements from the experience units.  It records
    statistics on note lengths and parses any numeric values with simple
    units (seconds, minutes, feet, degrees).  These metrics may later be
    used by causal and feedback layers.
    """
    lengths = [len(xu.notes) for xu in xus]
    overall_metrics: Dict[str, Any] = {
        "count": len(xus),
        "notes_length": {
            "mean": mean(lengths) if lengths else 0,
            "stdev": stdev(lengths) if len(lengths) > 1 else 0,
            "min": min(lengths) if lengths else 0,
            "max": max(lengths) if lengths else 0,
        },
    }
    # Regex to capture numeric values and their units.  Supports a variety of
    # measurement units such as time, distance, speed, weight and percentages.
    import re
    num_re = re.compile(
        r"(\d+(?:\.\d+)?)(?:\s*)(seconds?|mins?|minutes?|hours?|hrs?|h|ft|feet|meters?|m|km|kilometers?|miles?|mph|kph|km/h|kg|kilograms?|lbs?|pounds?|degrees?|deg|°|%)",
        re.IGNORECASE,
    )
    per_xu_metrics: Dict[str, Any] = {}
    for xu in xus:
        matches = num_re.findall(xu.notes)
        values = []
        for value, unit in matches:
            try:
                val = float(value)
            except ValueError:
                continue
            values.append({"value": val, "unit": unit.lower()})
        if values:
            per_xu_metrics[xu.id] = values
    # Compute simple deltas across adjacent units within the same source
    deltas: List[Dict[str, Any]] = []
    # Group XUs by source preserving order
    by_src: Dict[str, List[ExperienceUnit]] = {}
    for xu in xus:
        src = xu.source or "unknown"
        by_src.setdefault(src, []).append(xu)
    for src, units in by_src.items():
        # Already in ingestion order
        for i in range(len(units) - 1):
            a = units[i]
            b = units[i + 1]
            # Delta on notes length
            deltas.append({
                "metric": "notes_length",
                "from": a.id,
                "to": b.id,
                "delta": len(b.notes) - len(a.notes),
            })
            # Delta on first numeric value if both have numeric metrics
            vals_a = per_xu_metrics.get(a.id)
            vals_b = per_xu_metrics.get(b.id)
            if vals_a and vals_b:
                va = vals_a[0]
                vb = vals_b[0]
                try:
                    delta = float(vb["value"]) - float(va["value"])
                    metric_name = vb["unit"]
                    deltas.append({
                        "metric": metric_name,
                        "from": a.id,
                        "to": b.id,
                        "delta": delta,
                    })
                except Exception:
                    pass
    # Generate simple validator heuristics based on action verbs
    validators: Dict[str, List[Dict[str, Any]]] = {}
    kinetic_actions = ontology.get("kinetic", {}).get("actions", [])
    for action in kinetic_actions:
        aid = action.get("id")
        verb = action.get("verb", "") if isinstance(action, dict) else ""
        tests: List[Dict[str, Any]] = []
        # Basic heuristic: increasing verbs should increase notes length
        if verb in {"increase", "open", "extend", "raise", "grow"}:
            tests.append({"metric": "notes_length", "test": ">0"})
        elif verb in {"decrease", "close", "reduce", "lower", "shrink"}:
            tests.append({"metric": "notes_length", "test": "<0"})
        if tests:
            validators[aid] = tests
    ontology["metric"] = {
        "summary": overall_metrics,
        "values": per_xu_metrics,
        "deltas": deltas,
        "validators": validators,
    }
    return ontology
