"""
Contextual layer builder.

This layer models external conditions that influence how actions perform.
Since our simple extraction does not include such information, we assign a
default context tag to all experience units.  In a production system, this
module would detect environmental conditions (e.g. weather, load, user skill)
and attach modifiers to edges.
"""

from typing import Dict, List, Any
from ..models import ExperienceUnit


def build(xus: List[ExperienceUnit], ontology: Dict[str, Any]) -> Dict[str, Any]:
    """Populate the context layer.

    Assigns a context to each experience unit based on its source file name
    and simple environment keywords in the notes.  Each unique context is
    recorded with a description.  This creates a mapping from units to
    contexts for higher‑level reasoning.
    """
    import os
    contexts: Dict[str, Dict[str, Any]] = {}
    assignments: Dict[str, str] = {}
    # Keywords to identify environments
    env_keywords = {
        "indoor": ["indoor", "inside", "stall", "room"],
        "outdoor": ["outdoor", "outside", "arena", "field"],
        "classroom": ["classroom", "lecture", "training room"],
    }
    for xu in xus:
        # Base context on source file name
        base = xu.source or "unknown"
        ctx_id = base
        desc = f"Source file {base}"
        # Check environment keywords in notes to refine context
        note_lower = xu.notes.lower()
        for name, keywords in env_keywords.items():
            if any(kw in note_lower for kw in keywords):
                ctx_id = f"{base}:{name}"
                desc = f"{name.capitalize()} context from {base}"
                break
        contexts[ctx_id] = {
            "id": ctx_id,
            "description": desc,
        }
        assignments[xu.id] = ctx_id
    ontology["context"] = {
        "contexts": contexts,
        "assignments": assignments,
    }
    return ontology
