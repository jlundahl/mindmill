"""
Temporal layer builder.

This layer models the ordering and timing of experience units.  The default
implementation records simple action sequences and their frequencies.  In a
production system, durations, delays and complex temporal relations would be
captured here.
"""

from collections import Counter, defaultdict
from typing import Dict, List, Any, Tuple, Optional
from ..models import ExperienceUnit


def _parse_time(ts: Optional[str]) -> Optional[int]:
    """Parse a timestamp of the form HH:MM or HH:MM:SS into seconds.

    Returns None if the timestamp is not in a recognised format.
    """
    if not ts:
        return None
    parts = ts.split(":")
    try:
        parts = [int(p) for p in parts]
    except Exception:
        return None
    if len(parts) == 2:
        # MM:SS or HH:MM? assume mm:ss
        return parts[0] * 60 + parts[1]
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    return None


def build(xus: List[ExperienceUnit], ontology: Dict[str, Any]) -> Dict[str, Any]:
    """Populate the temporal layer.

    Builds bigram sequences of actions grouped by source file and records
    simple lag times between consecutive units if timestamps are
    available.  The bigram list includes the source identifier so that
    temporal patterns can be analysed within each context.
    """
    # Group units by source to preserve local order
    by_src: Dict[str, List[ExperienceUnit]] = {}
    for xu in xus:
        src = xu.source or "unknown"
        by_src.setdefault(src, []).append(xu)
    bigrams: List[Dict[str, Any]] = []
    lag_records: List[Dict[str, Any]] = []
    for src, units in by_src.items():
        # Already in ingestion order; iterate pairs
        for i in range(len(units) - 1):
            a = units[i]
            b = units[i + 1]
            bigrams.append({"src": src, "a": a.action, "b": b.action})
            t1 = _parse_time(a.timestamp)
            t2 = _parse_time(b.timestamp)
            if t1 is not None and t2 is not None and t2 >= t1:
                lag_records.append({"from": a.id, "to": b.id, "lag_s": t2 - t1})
    # Compute frequency of action pairs (ignoring source)
    counter = Counter((bg["a"], bg["b"]) for bg in bigrams)
    sequences = [
        {"from": a1, "to": a2, "count": count}
        for (a1, a2), count in counter.items()
    ]
    ontology["temporal"] = {
        "bigrams": bigrams,
        "sequences": sequences,
        "lags": lag_records,
        "stats": {"count": len(bigrams)},
    }
    return ontology
