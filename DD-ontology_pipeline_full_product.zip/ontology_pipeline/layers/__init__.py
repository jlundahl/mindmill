"""
Layer package for the ontology pipeline.

Each module in this package exposes a function :func:`build` that takes a list
of ExperienceUnits and a partially constructed ontology dictionary.  The
function should add its layer's data to the ontology and return the updated
dictionary.  Layers are executed in the order specified by
:class:`~ontology_pipeline.ontology.OntologyBuilder`.
"""

from importlib import import_module
from typing import List
from ..models import ExperienceUnit


def get_layer_modules() -> List[str]:
    """Return the fully qualified module names for all layers.

    The ordering defined here determines the order of execution in the
    ontology builder.  New layers can be added to this list without
    modifying other code.
    """
    return [
        "ontology_pipeline.layers.semantic",
        "ontology_pipeline.layers.kinetic",
        "ontology_pipeline.layers.metric",
        "ontology_pipeline.layers.constraint",
        "ontology_pipeline.layers.temporal",
        "ontology_pipeline.layers.causal",
        "ontology_pipeline.layers.context",
        "ontology_pipeline.layers.governance",
        "ontology_pipeline.layers.feedback",
        "ontology_pipeline.layers.narrative",
        "ontology_pipeline.layers.value",
        # Conflict detection should run after all other primary layers
        "ontology_pipeline.layers.conflict",
    ]


def load_layers() -> List:
    """Dynamically import and return layer modules in order."""
    modules = []
    for name in get_layer_modules():
        modules.append(import_module(name))
    return modules
