"""
Feedback layer builder.

This layer maintains health and performance metrics for edges based on the
observed outcomes.  In this simplified implementation, we judge an
experience unit as a success if the note length decreases in the following
unit (indicating more concise description) and record basic statistics per
action.
"""

from typing import Dict, List, Any
from collections import defaultdict
from ..models import ExperienceUnit


def build(xus: List[ExperienceUnit], ontology: Dict[str, Any]) -> Dict[str, Any]:
    """Populate the feedback layer.

    Computes rudimentary success metrics for each action.  An action is
    considered successful if the note contains any positive keywords
    (e.g. 'calm', 'improve', 'increase', 'soften') and does not contain
    negative keywords (e.g. 'brace', 'struggle', 'fail').  A real system
    should use actual sensor feedback and quantitative metrics.
    """
    from collections import defaultdict
    positive = {"calm", "relax", "improve", "increase", "soften", "accept", "yield", "progress"}
    negative = {"brace", "struggle", "fail", "tense", "resist", "fear"}
    results: Dict[str, List[bool]] = defaultdict(list)
    for xu in xus:
        note = xu.notes.lower()
        success = False
        if any(p in note for p in positive) and not any(n in note for n in negative):
            success = True
        results[xu.action].append(success)
    stats = {}
    for action, flags in results.items():
        if flags:
            rate = sum(1 for flag in flags if flag) / len(flags)
        else:
            rate = 0.0
        stats[action] = {
            "observations": len(flags),
            "success_rate": rate,
        }
    ontology["feedback"] = {
        "actions": stats,
    }
    return ontology
