"""
Value layer builder.

This layer associates perceptible value with each kinetic edge, inspired by
the Genius System framework.  Each entry captures the reason for performing
the step, the value it creates and a classification of that value as
functional, emotional or financial.  In the simplified implementation, we
derive these values from the notes length and position in the sequence.
"""

from typing import Dict, List, Any
from ..models import ExperienceUnit


def build(xus: List[ExperienceUnit], ontology: Dict[str, Any]) -> Dict[str, Any]:
    """Populate the value layer.

    Parses each experience unit's notes to find explicit motivation language
    such as “so that”, “because”, “without” etc., and assigns a value type
    based on detected keywords.  If no connector is found, a generic
    explanation is provided.
    """
    import re
    # Define connectors used to signal perceived reasons
    connectors = [
        "so that",
        "because",
        "in order to",
        "so you can",
        "so you don't have to",
        "even if",
        "without",
        "otherwise",
    ]
    # Keywords for value classification
    emotional_kw = {
        "feel",
        "confident",
        "confidence",
        "safe",
        "enjoy",
        "happy",
        "hope",
        "fear",
        "stress",
        "trust",
        "peace",
        "love",
    }
    financial_kw = {
        "money",
        "cost",
        "profit",
        "income",
        "expense",
        "fee",
        "revenue",
        "savings",
        "investment",
        "financial",
        "price",
    }
    values: Dict[str, Dict[str, Any]] = {}
    for xu in xus:
        note_lower = xu.notes.lower()
        reason = None
        # Find first occurrence of any connector
        for conn in connectors:
            idx = note_lower.find(conn)
            if idx != -1:
                # Extract everything after the connector
                reason = xu.notes[idx + len(conn) :].strip()
                break
        if not reason:
            # No connector; fall back to a default explanation based on first sentence
            # Use the first clause up to punctuation as the perceived reason
            m = re.search(r"\. |, |; |! |\? ", xu.notes)
            if m:
                reason = xu.notes[m.start() :].strip()
            else:
                reason = xu.notes
        # Classify value type based on keywords
        val_lower = reason.lower()
        vtype = "Functional"
        if any(kw in val_lower for kw in emotional_kw):
            vtype = "Emotional"
        elif any(kw in val_lower for kw in financial_kw):
            vtype = "Financial"
        values[xu.action] = {
            "perceived_reason": reason,
            "value_created": reason,
            "value_type": vtype,
        }
    ontology["value"] = {
        "actions": values,
    }
    return ontology
