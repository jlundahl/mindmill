"""
Semantic layer builder.

This layer extracts high‑level concepts from the notes of each experience unit.
The default implementation tokenizes each note on whitespace and records the
unique words as entities.  In a real deployment, this layer would identify
domain entities, roles, hierarchies and synonyms.
"""

from collections import Counter, defaultdict
from typing import Dict, List, Any, Tuple
import re
from ..models import ExperienceUnit
from ..nlp_backend import get_backend

# Predefined sets for basic ontology categorisation.
# Known human roles. Extend this set for your domain.
KNOWN_ROLES = {
    "trainer", "instructor", "coach", "rider", "student", "client",
    "operator", "technician", "assistant", "handler", "teacher", "mentor",
}
# Known animal terms
KNOWN_ANIMALS = {
    "horse", "colt", "mare", "gelding", "stallion", "filly", "pony"
}
# Known objects/tools used in training contexts
KNOWN_OBJECTS = {
    "saddle", "bridle", "rein", "halter", "rope", "lead", "whip", "blanket",
    "bit", "pad", "cinch",
}
# Known conceptual terms (skills and qualities)
KNOWN_CONCEPTS = {
    "yield", "bend", "flexion", "softness", "impulsion", "release",
    "balance", "rhythm", "collection", "extension", "suppleness",
    "cadence", "brace", "acceptance", "confidence", "trust",
}

# Stopwords used to ignore common words when extracting triples
STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "if", "then", "when", "so",
    "that", "because", "in", "on", "to", "with", "as", "by", "for",
    "of", "at", "from", "into", "during", "including", "until", "against",
    "among", "throughout", "per", "about", "towards", "upon", "around",
    "than", "after", "before", "under", "without", "within", "along",
    "following", "across", "behind", "beyond", "plus", "except",
}


def build(xus: List[ExperienceUnit], ontology: Dict[str, Any]) -> Dict[str, Any]:
    """Populate the semantic layer of the ontology.

    This implementation attempts a more sophisticated extraction of
    high‑level concepts, relationships, hierarchies and synonyms from
    experience unit notes.  It classifies tokens into roles, animals,
    objects, concepts and names, assigns each entity a unique identifier,
    builds a simple hierarchy of categories, identifies morphological
    synonyms (plural/singular), and extracts subject‑verb‑object
    relationships using basic heuristics.  These heuristics are not
    perfect but provide a richer semantic map than raw term counts.
    """
    # Containers for extracted semantics
    entities: Dict[str, Dict[str, Any]] = {}
    term_freq: Counter = Counter()
    relationships: List[Dict[str, Any]] = []
    synonyms: Dict[str, str] = {}
    hierarchies: Dict[str, str] = {}

    # Instantiate NLP backend once per build call
    nlp = get_backend()

    ent_counter = 0

    def add_entity(name: str, ent_type: str) -> str:
        """Return the id of an entity, adding it if not present.

        Parameters
        ----------
        name : str
            Canonical lowercase name for the entity.
        ent_type : str
            One of 'role', 'animal', 'object', 'concept', 'person'.

        Returns
        -------
        str
            The unique identifier for this entity.
        """
        nonlocal ent_counter
        key = name.lower()
        for ent_id, ent in entities.items():
            if ent["name"] == key:
                return ent_id
        ent_id = f"ENT{ent_counter:04d}"
        ent_counter += 1
        entities[ent_id] = {
            "id": ent_id,
            "name": key,
            "type": ent_type,
        }
        # Record a hierarchy entry: map entity id to its high‑level category
        hierarchies[ent_id] = ent_type
        return ent_id

    def canonical_form(word: str) -> str:
        """Return a canonical form for a word (simple singularisation).

        If a plural word ends with 's' and the singular exists in the
        vocabulary, return the singular.  Otherwise return lowercase
        unchanged.
        """
        w = word.lower()
        # Basic plural to singular handling: remove trailing 's'
        if w.endswith("s") and len(w) > 3:
            return w[:-1]
        return w

    # Pass 1: collect term frequencies and build preliminary entity list
    # Also collect person names and link them to roles using NLP backend
    for xu in xus:
        text = xu.notes
        # Update term frequencies
        for token in re.findall(r"\b\w+\b", text.lower()):
            term_freq[token] += 1
        lower_text = text.lower()
        # Identify roles, animals, objects, concepts via keyword sets
        for token in re.findall(r"\b\w+\b", lower_text):
            if token in KNOWN_ROLES:
                add_entity(token, "role")
            if token in KNOWN_ANIMALS:
                add_entity(token, "animal")
            if token in KNOWN_OBJECTS:
                add_entity(token, "object")
            if token in KNOWN_CONCEPTS:
                add_entity(token, "concept")
        # Identify proper names using NLP backend (PERSON entities)
        for label, name, span in nlp.ents(text):
            if label == "PERSON":
                add_entity(name, "person")
        # Link persons to roles if found in proximity (e.g. "trainer John")
        # Build a list of person names extracted from this unit
        person_names = [name for label, name, _span in nlp.ents(text) if label == "PERSON"]
        for person_name in person_names:
            # Normalize whitespace in name for matching
            pname = person_name.strip()
            for role in KNOWN_ROLES:
                # Pattern: role followed by name (e.g. "trainer John")
                if re.search(fr"\b{re.escape(role)}\s+{re.escape(pname)}\b", lower_text, re.IGNORECASE):
                    # Add role entity if not already
                    rid = add_entity(role, "role")
                    pid = add_entity(pname, "person")
                    relationships.append({
                        "subject": pid,
                        "relation": "has_role",
                        "object": rid,
                        "xu_id": xu.id,
                        "type": "role_assignment",
                    })
                # Pattern: name followed by role (e.g. "John the trainer")
                if re.search(fr"\b{re.escape(pname)}\s+(?:the\s+)?{re.escape(role)}\b", lower_text, re.IGNORECASE):
                    rid = add_entity(role, "role")
                    pid = add_entity(pname, "person")
                    relationships.append({
                        "subject": pid,
                        "relation": "has_role",
                        "object": rid,
                        "xu_id": xu.id,
                        "type": "role_assignment",
                    })
    # Build simple synonym map (singular vs plural forms)
    for term in list(term_freq.keys()):
        canonical = canonical_form(term)
        if canonical != term:
            # Map plural to singular form
            synonyms[term] = canonical
    # Pass 2: extract relationships using a naive subject‑verb‑object pattern
    for xu in xus:
        words = re.findall(r"\b\w+\b", xu.notes)
        subj = None
        verb = None
        obj = None
        # Find a subject: first non‑stopword word
        for w in words:
            w_lower = w.lower()
            if w_lower not in STOPWORDS and w_lower.isalpha():
                subj = w_lower
                break
        # Find a verb: look for a word ending with typical verb inflections
        if subj:
            for w in words:
                w_lower = w.lower()
                if re.match(r"^[a-zA-Z]+(ed|ing|s)$", w_lower):
                    verb = w_lower
                    break
        # Find an object: next non‑stopword after verb
        if verb:
            found_verb = False
            for w in words:
                w_lower = w.lower()
                if w_lower == verb:
                    found_verb = True
                    continue
                if found_verb and w_lower not in STOPWORDS:
                    obj = w_lower
                    break
        if subj and verb and obj:
            relationships.append({
                "subject": subj,
                "relation": verb,
                "object": obj,
                "xu_id": xu.id,
                "type": "svo",
            })
        # Additionally, capture conditional relationships like "if X then Y"
        # Very simple pattern: find "if ... then ..." clauses
        lower = xu.notes.lower()
        if "if" in lower and "then" in lower:
            try:
                before, after = lower.split("if", 1)[1].split("then", 1)
                cond = before.strip().rstrip(",.")
                cons = after.strip().rstrip(",.")
                relationships.append({
                    "condition": cond,
                    "consequence": cons,
                    "xu_id": xu.id,
                    "type": "if_then",
                })
            except ValueError:
                pass
    # Assemble semantic layer
    ontology["semantic"] = {
        "entities": entities,
        "hierarchies": hierarchies,
        "synonyms": synonyms,
        "terms": dict(term_freq),
        "relationships": relationships,
    }
    return ontology
