"""
Narrative layer builder.

This layer captures the human‑readable narrative associated with the
experience units.  It stores notes in sequence and groups them into a
continuous story.  Narrative elements can be used by the blueprint builder to
produce richly annotated training materials.
"""

from typing import Dict, List, Any
from ..models import ExperienceUnit


def build(xus: List[ExperienceUnit], ontology: Dict[str, Any]) -> Dict[str, Any]:
    """Populate the narrative layer.

    Stores a list of notes and a concatenated story string.
    """
    sorted_xus = sorted(xus, key=lambda xu: xu.id)
    notes = [xu.notes for xu in sorted_xus]
    story = "\n".join(notes)
    ontology["narrative"] = {
        "notes": notes,
        "story": story,
    }
    return ontology
