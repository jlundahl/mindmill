"""
Causal layer builder.

This layer attempts to infer cause–effect relationships between actions and
observed metrics.  In this simplified implementation we use the change in
note length between consecutive experience units as a proxy for an outcome
change.  The resulting causal map records whether an action is associated
with an increase, decrease or no change in this proxy metric.
"""

from typing import Dict, List, Any
from ..models import ExperienceUnit


def build(xus: List[ExperienceUnit], ontology: Dict[str, Any]) -> Dict[str, Any]:
    """Populate the causal layer.

    This implementation extracts explicit and implicit cause–effect
    relationships from each experience unit.  It scans for motivation
    connectors such as "because", "so that", "in order to", etc., and
    creates edges linking the current action to the described effect.
    Additionally, it captures temporal ordering between sequential
    actions, and detects potential conflicts where two actions produce
    contradictory effects (e.g. one encourages an outcome while another
    discourages it).  A list of edges and conflicts is returned in the
    causal layer.
    """
    # Motivation connectors to look for in notes
    # Motivation connectors to look for in notes.  The list has been
    # expanded to cover a broader range of causal phrases including
    # single words ("so", "then", "thus", "therefore") and
    # domain‑specific expressions.  Additional connectors can be
    # configured via a YAML file in the future.
    connectors = [
        "because",
        "so that",
        "so you can",
        "so we can",
        "so the",
        "so",
        "then",
        "therefore",
        "thus",
        "hence",
        "in order to",
        "so you don't have to",
        "even if",
        "without",
        "otherwise",
        "to",
        "for the purpose of",
    ]
    explicit_edges: List[Dict[str, Any]] = []
    temporal_edges: List[Dict[str, Any]] = []
    # Store for conflict detection: key by effect description normalised
    effect_map: Dict[str, List[Tuple[str, str]]] = {}
    for xu in xus:
        text_lower = xu.notes.lower()
        found = False
        for conn in connectors:
            idx = text_lower.find(conn)
            if idx != -1:
                effect_text = xu.notes[idx + len(conn) :].strip()
                explicit_edges.append({
                    "cause_action": xu.action,
                    "effect_description": effect_text,
                    "xu_id": xu.id,
                    "connector": conn,
                    "type": "explicit",
                })
                # Normalise effect description for conflict detection
                norm = effect_text.lower().strip().rstrip(".!")
                effect_map.setdefault(norm, []).append((xu.action, conn))
                found = True
                break
        # Note: implicit effects (no connector) are not captured here
    # Temporal ordering: each action influences the next action implicitly
    sorted_xus = sorted(xus, key=lambda xu: xu.id)
    for i in range(len(sorted_xus) - 1):
        temporal_edges.append({
            "cause_action": sorted_xus[i].action,
            "effect_action": sorted_xus[i + 1].action,
            "type": "temporal",
        })
    # Detect conflicts: same effect described by multiple connectors
    conflicts: List[Dict[str, Any]] = []
    for norm_effect, acts in effect_map.items():
        # If two or more actions share this effect description but with opposing connectors
        # mark a conflict if there is at least one negative connector (without/so you don't have to) and one positive (because/so that)
        has_negative = any(conn in {"without", "so you don't have to", "avoid"} for _, conn in acts)
        has_positive = any(conn in {"because", "so that", "so you can", "in order to"} for _, conn in acts)
        if has_negative and has_positive and len(acts) > 1:
            conflicts.append({
                "effect": norm_effect,
                "actions": [a for a, _ in acts],
                "connectors": [c for _, c in acts],
                "description": f"Conflicting motivations for effect '{norm_effect}'",
            })
    ontology["causal"] = {
        "explicit_edges": explicit_edges,
        "temporal_edges": temporal_edges,
        "conflicts": conflicts,
    }
    return ontology
