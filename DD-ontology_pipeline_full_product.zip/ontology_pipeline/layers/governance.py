"""
Governance layer builder.

This layer associates actions with roles and permissions.  In a minimal setup
we assign a generic role to all actions and define that they require no
special permits.  Real systems would integrate with HR or IAM databases to
determine role capabilities and audits.
"""

from typing import Dict, List, Any
from ..models import ExperienceUnit

# Use the same known roles as the semantic layer.  Ideally this would be
# imported from a common module, but duplication is acceptable for clarity.
KNOWN_ROLES = {
    "trainer", "instructor", "coach", "rider", "student", "horse",
    "client", "operator", "technician", "assistant",
}


def build(xus: List[ExperienceUnit], ontology: Dict[str, Any]) -> Dict[str, Any]:
    """Populate the governance layer.

    Defines a default role and maps all actions to that role.
    """
    roles: Dict[str, Dict[str, Any]] = {}
    assignments: Dict[str, List[str]] = {}
    # Ensure at least one default role exists
    roles["role_default"] = {
        "name": "default",
        "permissions": ["*"],
        "description": "Default role with full permissions for unspecified actors.",
    }
    for xu in xus:
        note_lower = xu.notes.lower()
        found_roles: List[str] = []
        for role in KNOWN_ROLES:
            if role in note_lower:
                role_id = f"role_{role}"
                if role_id not in roles:
                    roles[role_id] = {
                        "name": role,
                        "permissions": ["*"],
                        "description": f"Role derived from mention of {role}",
                    }
                found_roles.append(role_id)
        if not found_roles:
            found_roles.append("role_default")
        assignments.setdefault(xu.action, []).extend(found_roles)
    ontology["governance"] = {
        "roles": roles,
        "assignments": assignments,
    }
    return ontology
