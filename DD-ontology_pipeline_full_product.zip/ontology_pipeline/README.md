# Ontology Pipeline

This repository contains a modular ingestion and ontology‐building pipeline designed to
transform large, messy corpora of text into a structured knowledge base.  The
pipeline constructs a multi‑layered ontology that can be consumed by downstream
LLMs or agents to reason about a domain, speak in the voice of the original
expert, and generate both operational guidance and training materials.

## Overview
...
## Quickstart (It Just Works)

1) Create a Python 3.10+ venv and install deps:
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

2) Put a few small `.txt` files in a folder, e.g. `./data`:
```bash
mkdir -p data && printf 'Trainer John asks for bend so that the horse softens.\n' > data/sample.txt
```

3) Run the pipeline from the project root (this folder) using the
package entry point.  You can invoke either the ``main`` module or
the package itself via ``-m ontology_pipeline``:
```bash
# Recommended: run the package directly
python -m ontology_pipeline \
  --input-dir ./data \
  --output-file ./out/ontology.json \
  --blueprint-file ./out/blueprint.json

# Alternatively, call the main module explicitly
python -m ontology_pipeline.main \
  --input-dir ./data \
  --output-file ./out/ontology.json \
  --blueprint-file ./out/blueprint.json
```
Both forms produce two JSON artefacts:

* ``ontology.json`` – a multilayered knowledge graph containing semantic,
  kinetic, temporal, causal, narrative, value and other layers.
* ``blueprint.json`` – a **nested skill tree** built from the ontology.  It
  exposes an ``ultimate_promise`` (the high‑level goal), a list of
  ``key_outcomes`` (compact effect summaries) and a ``protocol``.  The
  protocol is a hierarchy of steps identified by their stable slugs.  Each
  step includes a human‑readable phrase, compact reasons and values, a
  value type tag and nested ``children`` representing downstream actions.
  Downstream agents or LLMs can use this structure to navigate from meta
  goals down to atomic actions without losing context.

4) Optional: install spaCy for richer name/entity extraction.  The
default model ``en_core_web_sm`` is sufficient and lighter than
``en_core_web_md``.  Install spaCy and download the model, then
rerun with the ``--nlp spacy`` flag:
```bash
pip install spacy && python -m spacy download en_core_web_sm
python -m ontology_pipeline \
  --input-dir ./data \
  --output-file ./out/ontology_spacy.json \
  --blueprint-file ./out/blueprint_spacy.json \
  --nlp spacy
```

5) **Incremental updates**: once you've built an ontology, you can ingest
additional data over time without losing prior knowledge.  Pass the
`--update` flag together with `--existing-ontology` pointing at the
previous ontology JSON.  The pipeline will load any previously stored
experience units (saved under the special key `_experience_units`) from
that file, concatenate them with newly ingested units and rebuild the
ontology and blueprint.  For example:

```bash
# initial build
python -m ontology_pipeline.main --input-dir ./data --output-file ./out/ontology.json --blueprint-file ./out/ontology.json
# later, add more files in ./more_data and update the ontology
python -m ontology_pipeline.main --input-dir ./more_data --output-file ./out/ontology.json \
    --existing-ontology ./out/ontology.json --update --blueprint-file ./out/blueprint.json
```
This will produce an updated ontology that contains information from both
`./data` and `./more_data`, while preserving all previously extracted
experience units.

### Troubleshooting
- **Empty or tiny outputs**: start with small text files (a few KB). Very large corpora may exceed memory in low‑resource environments.
* **Module not found when running**: you can now run the pipeline via
  ``python -m ontology_pipeline`` from anywhere on your system as long
  as the package is installed or your current working directory
  contains the project root.  The new ``__main__`` entry point
  resolves the previous import issue.  If you still see ``ModuleNotFoundError``
  messages, ensure that the parent directory of ``ontology_pipeline``
  is on your ``PYTHONPATH`` or install the package via ``pip install .``.
- **Names not detected**: try `--nlp spacy` after installing spaCy per step 4.
 - **Invalid or corrupted ontology file**: if you pass `--existing-ontology` and the file
   does not exist or contains malformed JSON, the update step is skipped and
   the pipeline falls back to building a fresh ontology from the new input.
