"""
Utility functions for the ontology pipeline.
"""

from __future__ import annotations

import json
import os
from typing import Any, Generator, List

def generate_id(prefix: str, counter: int) -> str:
    """Generate a deterministic identifier with a given prefix and counter."""
    return f"{prefix}{counter:06d}"


def read_text_files(input_dir: str) -> Generator[tuple[str, str], None, None]:
    """Yield the path and contents of all `.txt` files in a directory tree.

    Parameters
    ----------
    input_dir : str
        Root directory to search for text files.

    Yields
    ------
    Tuple[str, str]
        A pair of the file path and the full text of each file found.
    """
    for root, _, files in os.walk(input_dir):
        for fname in files:
            if fname.lower().endswith(".txt"):
                path = os.path.join(root, fname)
                try:
                    with open(path, "r", encoding="utf-8", errors="ignore") as f:
                        yield path, f.read()
                except OSError:
                    continue


def save_json(data: Any, path: str) -> None:
    """Serialize data as JSON to the given path."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def load_json(path: str) -> Any:
    """
    Load JSON data from a file if it exists and is well-formed.

    If the file is missing or contains malformed JSON, this function
    returns ``None`` instead of raising an exception.  Callers should
    always check for ``None`` before using the returned value.

    Parameters
    ----------
    path : str
        Path to a JSON file to load.

    Returns
    -------
    Any or None
        The parsed JSON content if valid, otherwise ``None``.

    Notes
    -----
    This helper centralises error handling for reading JSON.  It
    catches :class:`json.JSONDecodeError` raised by :func:`json.load` and
    returns ``None`` so that higher-level code can detect invalid
    ontologies and fall back to a fresh build during incremental
    updates.
    """
    # If the file doesn't exist, there's nothing to load.
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        # Malformed JSON – return None instead of raising.
        return None
