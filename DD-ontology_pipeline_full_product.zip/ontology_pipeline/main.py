"""
Command line interface for the ontology pipeline.

This module provides an entry point for running the entire ingestion and
ontology building process from the command line.  It reads raw data from
files, constructs an ontology, optionally merges with an existing
ontology, and writes the result to JSON.  It can also produce a
blueprint describing the ultimate promise and the reverse‑engineered
sequence of steps with their perceived value.
"""

from __future__ import annotations

import argparse
import sys
from typing import Optional

from .ingestion import ingest_directory
from .nlp_backend import set_backend
from .models import Ontology, ExperienceUnit
from .ontology import OntologyBuilder
from .utils import save_json, load_json, generate_id
from dataclasses import asdict
from .blueprint import BlueprintBuilder


def parse_args(argv: Optional[list] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a multi‑layer ontology from raw data.")
    parser.add_argument("--input-dir", required=True, help="Directory containing raw text files.")
    parser.add_argument("--output-file", required=True, help="Path to write the ontology JSON.")
    parser.add_argument("--blueprint-file", help="Path to write the blueprint JSON.")
    parser.add_argument("--existing-ontology", help="Path to an existing ontology JSON to merge into.")
    parser.add_argument("--update", action="store_true", help="Merge new data into existing ontology instead of replacing it.")
    parser.add_argument("--ultimate-promise", help="Override the automatic ultimate promise selection.")
    parser.add_argument("--nlp", choices=["regex", "spacy"], default="regex",
                        help="Select NLP backend: 'regex' (default) or 'spacy' if installed.")
    return parser.parse_args(argv)


def main(argv: Optional[list] = None) -> None:
    args = parse_args(argv)
    # Configure NLP backend
    set_backend(args.nlp)
    # Ingest raw data
    new_xus = ingest_directory(args.input_dir)

    # When performing an update, load any previously stored experience units
    # from the existing ontology.  These units are saved under the
    # special key "_experience_units" in the ontology JSON.  We then
    # concatenate them with the newly ingested units to build a complete
    # corpus for incremental ontology construction.  If no previous units
    # exist or the update flag is not set, we build solely from the
    # newly ingested units.
    combined_xus: list[ExperienceUnit] = []
    # The previous ontology layers (excluding stored XUs) are loaded
    # separately; we rebuild the ontology from scratch using all XUs
    # rather than performing layer‑wise merging in order to ensure
    # consistent statistics and relationships.
    prev_layers: Optional[Ontology] = None
    if args.update and args.existing_ontology:
        data = load_json(args.existing_ontology)
        if data:
            # Extract any persisted experience units
            prev_units_data = data.pop("_experience_units", None)
            if isinstance(prev_units_data, list):
                for xu_data in prev_units_data:
                    try:
                        combined_xus.append(ExperienceUnit(**xu_data))
                    except Exception:
                        # Ignore malformed entries
                        pass
            # The remaining dict entries represent previously built layers
            prev_layers = Ontology(layers=data)
    # Append newly ingested units
    # Append newly ingested units; renumber them if updating to avoid ID collisions
    if args.update:
        # Determine the highest existing counter from previous units
        max_counter = -1
        for xu in combined_xus:
            # Expect IDs of the form 'xu_XXXXXX'
            if isinstance(xu.id, str) and xu.id.startswith("xu_"):
                try:
                    num = int(xu.id[3:])
                    if num > max_counter:
                        max_counter = num
                except Exception:
                    continue
        # Start numbering new units after the highest existing index
        counter = max_counter + 1
        for xu in new_xus:
            new_id = generate_id("xu_", counter)
            counter += 1
            xu.id = new_id
            # Update dependent fields based on the new id
            xu.setup_state = f"S.{new_id}_pre"
        combined_xus.extend(new_xus)
    else:
        # Fresh build: combined_xus is just the newly ingested units
        combined_xus = new_xus
    # Build ontology from all units
    builder = OntologyBuilder()
    ontology = builder.build(combined_xus, prev_layers)
    # Prepare the ontology dict and include the combined units for future
    # incremental updates.  We store the raw dataclass fields to aid
    # reconstruction on subsequent runs.  The special key
    # "_experience_units" is reserved and not used by any layer.
    out_dict = ontology.to_dict()
    out_dict["_experience_units"] = [asdict(xu) for xu in combined_xus]
    save_json(out_dict, args.output_file)
    # Generate blueprint if requested
    if args.blueprint_file:
        blueprint_builder = BlueprintBuilder(ontology, ultimate_promise=args.ultimate_promise)
        blueprint = blueprint_builder.build_blueprint()
        save_json(blueprint, args.blueprint_file)
    print(f"Ontology written to {args.output_file}")
    if args.blueprint_file:
        print(f"Blueprint written to {args.blueprint_file}")


if __name__ == "__main__":
    main()
