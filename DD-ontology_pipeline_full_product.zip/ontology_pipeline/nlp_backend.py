"""
NLP backend module for the ontology pipeline.

This module provides lightweight natural language processing capabilities
that can optionally leverage third‑party libraries like spaCy.  When
available, spaCy can be used for higher‑quality named entity recognition
and linguistic analysis.  In the absence of spaCy, a simple regex‑based
backend is provided that performs basic proper name extraction.

The active backend can be selected at runtime via the ``set_backend``
function.  All layer modules should obtain a backend instance by
calling :func:`get_backend`, which instantiates the selected backend
implementation on demand.
"""

from __future__ import annotations

import re
from typing import List, Tuple, Optional


class RegexBackend:
    """A minimal NLP backend using regular expressions.

    The regex backend attempts to extract proper names by identifying
    capitalised words that are not sentence‑initial.  It emits tuples
    of the form ``(label, text, span)`` where ``label`` is always
    ``"PERSON"``, ``text`` is the matched name and ``span`` is the
    character offset within the input.  This backend does not perform
    any deeper linguistic analysis but provides a zero‑dependency
    fallback when spaCy is unavailable.
    """

    person_re = re.compile(r"(?<!\.\s)(?<!^)(\b[A-Z][a-z]{1,}\b(?:\s+[A-Z][a-z]{1,}\b)*)")

    def ents(self, text: str) -> List[Tuple[str, str, Tuple[int, int]]]:
        entities: List[Tuple[str, str, Tuple[int, int]]] = []
        for m in self.person_re.finditer(text):
            span = m.span()
            entities.append(("PERSON", m.group(1), span))
        return entities


try:
    import spacy  # type: ignore
    _nlp = spacy.load("en_core_web_sm")  # Attempt to load a small English model

    class SpacyBackend:
        """An NLP backend backed by spaCy.

        The spaCy backend uses an installed spaCy model to perform
        named entity recognition.  Only entities labelled ``PERSON`` or
        ``ORG`` are returned.  Additional linguistic features can be
        exposed by extending this class.
        """

        def ents(self, text: str) -> List[Tuple[str, str, Tuple[int, int]]]:
            doc = _nlp(text)
            ents: List[Tuple[str, str, Tuple[int, int]]] = []
            for ent in doc.ents:
                if ent.label_ in ("PERSON", "ORG"):
                    ents.append((ent.label_, ent.text, (ent.start_char, ent.end_char)))
            return ents

except Exception:
    SpacyBackend = None  # type: ignore


# Global state to select the active backend.  The default is ``regex``.
_BACKEND_NAME = "regex"


def set_backend(name: str) -> None:
    """Set the active NLP backend.

    Parameters
    ----------
    name : str
        Either ``"regex"`` for the simple regex backend or ``"spacy"`` for
        the spaCy backend.  If spaCy is unavailable, this function
        silently falls back to the regex backend.
    """
    global _BACKEND_NAME
    if name == "spacy" and SpacyBackend is not None:
        _BACKEND_NAME = "spacy"
    else:
        _BACKEND_NAME = "regex"


def get_backend() -> "RegexBackend | SpacyBackend":
    """Return an instance of the active NLP backend.

    The backend name is determined by :func:`set_backend`.  When
    ``"spacy"`` is selected but the spaCy model failed to load,
    :class:`RegexBackend` is used as a fallback.

    Returns
    -------
    RegexBackend or SpacyBackend
        An instance of the selected NLP backend implementation.
    """
    if _BACKEND_NAME == "spacy" and SpacyBackend is not None:
        return SpacyBackend()  # type: ignore
    return RegexBackend()