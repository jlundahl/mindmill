"""
Blueprint generation for the ontology pipeline.

The BlueprintBuilder extracts a coherent sequence of steps from the
constructed ontology and attaches perceptible value to each step in order to
produce training materials or system documentation.  It can operate on any
ontology produced by :class:`~ontology_pipeline.ontology.OntologyBuilder`.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .models import Ontology


class BlueprintBuilder:
    """Generates a rich blueprint and value table from an ontology.

    The blueprint encapsulates an "ultimate promise" (meta goal) along with
    a nested protocol of actionable steps derived from the causal and
    temporal layers.  Each step is annotated with compact reasons and
    value descriptions.  Key outcomes summarise high‑level effects.  When
    the pipeline ingests additional experience units, this builder
    automatically expands the protocol to include new actions in the
    appropriate order.
    """

    def __init__(self, ontology: Ontology, ultimate_promise: Optional[str] = None) -> None:
        # We store the ontology as a plain dict to avoid accidental
        # mutation of the original dataclass.  Persisted experience units
        # (under the `_experience_units` key) are ignored here.
        self.ontology: Dict[str, Any] = ontology.to_dict()
        self.ultimate_promise = ultimate_promise

    # ------------------------------------------------------------------
    # Utility functions
    # ------------------------------------------------------------------
    @staticmethod
    def _split_sentences(text: str) -> List[str]:
        """Naively split a string into sentences using punctuation.

        We use a simple heuristic rather than external NLP libraries to
        avoid adding heavyweight dependencies.  Splits on '.', '?', '!'
        followed by whitespace.  Returns at least one element even if
        punctuation is absent.
        """
        import re
        text = text.strip()
        if not text:
            return []
        # normalise whitespace
        text = " ".join(text.split())
        # split on punctuation followed by space
        sentences = re.split(r"(?<=[\.!?])\s+", text)
        return [s.strip() for s in sentences if s.strip()]

    @staticmethod
    def _compact(text: str, max_chars: int = 180, keywords: Optional[List[str]] = None) -> str:
        """Condense a block of text to a targeted character length.

        Sentences containing any of the provided keywords are scored higher
        and selected first.  We accumulate sentences until the length
        budget is exhausted.  If no keywords are provided, we simply
        take the first sentence(s) up to the limit.  Returned strings
        never exceed ``max_chars`` and are stripped of surrounding
        whitespace.
        """
        if not text:
            return ""
        sentences = BlueprintBuilder._split_sentences(text)
        if not sentences:
            return text[:max_chars].strip()
        # normalise keywords
        kw = [k.lower() for k in (keywords or [])]
        # score sentences by keyword hits and shorter length (higher is better)
        scored = []
        for s in sentences:
            s_lower = s.lower()
            score = sum(1 for k in kw if k in s_lower)
            # we want shorter sentences earlier when scores tie
            scored.append((score, -len(s), s))
        # sort by score descending then length ascending
        scored.sort(key=lambda x: ( -x[0], x[1] ))
        selected: List[str] = []
        total = 0
        for _, _, s in scored:
            if total + len(s) + (1 if selected else 0) > max_chars:
                # adding this sentence would exceed limit
                continue
            selected.append(s)
            total += len(s) + (1 if selected else 0)
            if total >= max_chars:
                break
        # fallback: if nothing was selected (e.g. all sentences too long), choose the first truncated sentence
        if not selected:
            return sentences[0][:max_chars].strip()
        return " ".join(selected)[:max_chars].strip()

    def _select_ultimate_promise(self) -> str:
        """Choose and compact the ultimate promise from the ontology.

        We honour any explicitly provided override.  Otherwise we derive
        a high‑level outcome from the longest effect description and
        compact it using a set of goal‑related keywords.  If no effect
        descriptions exist, we fall back to a generic promise.
        """
        # Use user override if provided
        if self.ultimate_promise:
            return self.ultimate_promise.strip()
        causal_layer = self.ontology.get("causal", {})
        explicit_edges = causal_layer.get("explicit_edges", [])
        longest = ""
        for edge in explicit_edges:
            desc = edge.get("effect_description", "")
            if len(desc) > len(longest):
                longest = desc
        if longest:
            # Capitalise first letter for readability and compact with goal keywords
            promise = longest[0].upper() + longest[1:]
            keywords = [
                "goal", "ultimately", "so that", "we want", "aim", "target",
                "outcome", "relax", "confidence", "control", "foundation", "rhythm",
            ]
            return self._compact(promise, max_chars=200, keywords=keywords)
        # Fall back to metric heuristic
        metric_layer = self.ontology.get("metric", {})
        notes_stats = metric_layer.get("notes_length", {})
        stdev = notes_stats.get("stdev")
        if stdev is not None and stdev > 0:
            return "Create concise, high‑impact instructions"
        return "Extract structured knowledge from unstructured data"

    def _derive_key_outcomes(self) -> List[str]:
        """Derive and compact a list of unique outcome descriptions.

        We examine all explicit causal edges and extract their effect
        descriptions.  Duplicate or empty descriptions are ignored.
        Each outcome is compacted to 140 characters with goal keywords.
        """
        causal_layer = self.ontology.get("causal", {})
        explicit_edges = causal_layer.get("explicit_edges", [])
        outcomes: List[str] = []
        seen: set[str] = set()
        keywords = [
            "goal", "so that", "because", "relax", "soften", "control",
            "stand", "confidence", "rhythm", "foundation",
        ]
        for edge in explicit_edges:
            desc = edge.get("effect_description", "").strip()
            if not desc:
                continue
            # normalise spacing
            desc_norm = " ".join(desc.split())
            if desc_norm.lower() in seen:
                continue
            seen.add(desc_norm.lower())
            outcomes.append(self._compact(desc_norm, max_chars=140, keywords=keywords))
        return outcomes

    def _extract_ordered_actions(self) -> List[str]:
        """Return a deduplicated list of actions in causal/temporal order.

        We begin from actions whose effects mention the ultimate promise.
        We then walk backwards along temporal edges to build a chain of
        prerequisites.  If none match, we default to all actions in the
        kinetic layer in their original order.  Duplicate actions are
        removed while preserving order.
        """
        promise = self._select_ultimate_promise().lower()
        causal_layer = self.ontology.get("causal", {})
        explicit_edges = causal_layer.get("explicit_edges", [])
        temporal_edges = causal_layer.get("temporal_edges", [])
        kinetic_edges = self.ontology.get("kinetic", {}).get("edges", [])
        # Collect actions from the value layer if available.  These
        # correspond to full slugs extracted from experience units and
        # provide richer identifiers than the kinetic layer's compact
        # names.  If no actions exist in the value layer, fall back to
        # the kinetic layer.
        value_actions = list(self.ontology.get("value", {}).get("actions", {}).keys())
        if value_actions:
            candidate_actions: List[str] = [a for a in value_actions if a]
        else:
            candidate_actions = [k.get("action") for k in kinetic_edges if k.get("action")]
            if not candidate_actions:
                candidate_actions = [edge.get("cause_action") for edge in explicit_edges if edge.get("cause_action")]
        # Build predecessor mapping from temporal edges (effect -> cause)
        predecessors: Dict[str, str] = {}
        for t_edge in temporal_edges:
            cause = t_edge.get("cause_action")
            effect = t_edge.get("effect_action")
            if cause and effect:
                # Only record first predecessor per effect for linearisation
                predecessors.setdefault(effect, cause)
        # Walk backwards from each candidate through predecessors
        steps: List[str] = []
        visited: set[str] = set()
        for action in candidate_actions:
            curr = action
            chain: List[str] = []
            while curr and curr not in visited:
                chain.append(curr)
                visited.add(curr)
                curr = predecessors.get(curr)
            steps.extend(chain)
        # De‑duplicate while preserving order
        ordered: List[str] = []
        seen: set[str] = set()
        for s in steps:
            if s and s not in seen:
                seen.add(s)
                ordered.append(s)
        return ordered

    def _slug_to_phrase(self, slug: str) -> str:
        """Convert an action slug into a human‑readable phrase.

        Strips the leading namespace prefix ("A.") and splits on
        underscores.  Capitalises the first word.  Example:
        ``A.coach_mary_instructs_to_push_action`` -> ``Coach mary instructs to push action``.
        If the slug does not conform, returns it unchanged.
        """
        if not slug or not slug.startswith("A."):
            return slug
        body = slug[2:]
        parts = body.split("_")
        if not parts:
            return slug
        return " ".join([parts[0].capitalize()] + parts[1:])

    def build_blueprint(self) -> Dict[str, Any]:
        """Generate a comprehensive blueprint from the ontology.

        The returned structure contains an ``ultimate_promise`` string, a list
        of ``key_outcomes`` and a detailed ``protocol``.  Each step in the
        protocol includes the slug, a human‑readable phrase, a compact
        perceived reason, the value created, the value type and the
        predecessor (if any).  Value descriptions are compacted using
        content‑appropriate keywords.  This representation should be
        sufficiently descriptive for a language model to infer
        relationships and missing context using the full ontology.
        """
        # Compute top‑level components
        promise = self._select_ultimate_promise().strip()
        key_outcomes = self._derive_key_outcomes()
        ordered_actions = self._extract_ordered_actions()
        # Prepare quick lookups
        value_layer = self.ontology.get("value", {}).get("actions", {})
        causal_layer = self.ontology.get("causal", {})
        temporal_edges = causal_layer.get("temporal_edges", [])
        # Map each action to its immediate predecessor (for nested linking)
        predecessors: Dict[str, Optional[str]] = {a: None for a in ordered_actions}
        for t_edge in temporal_edges:
            cause = t_edge.get("cause_action")
            effect = t_edge.get("effect_action")
            if cause and effect and effect in predecessors:
                # only record predecessor if both in our ordered list
                if predecessors.get(effect) is None:
                    predecessors[effect] = cause
        # Build protocol steps (flat list).  Each step initially
        # includes a predecessor pointer which will later be used to
        # construct a nested tree of children.
        protocol: List[Dict[str, Any]] = []
        # Keywords to highlight reasons and values
        reason_keywords = ["so that", "because", "aim", "goal", "control", "relax", "soften", "confident", "rhythm", "foundation"]
        value_keywords = ["relax", "accept", "confidence", "safety", "foundation", "rhythm", "control", "soften"]
        for action in ordered_actions:
            val = value_layer.get(action, {})
            raw_reason = val.get("perceived_reason", "") or ""
            raw_value = val.get("value_created", "") or ""
            reason = self._compact(raw_reason, max_chars=200, keywords=reason_keywords)
            value_desc = self._compact(raw_value, max_chars=160, keywords=value_keywords)
            # Derive or override value type based on keywords if not explicitly provided
            vtype = val.get("value_type", "").strip()
            if not vtype:
                vt_lower = value_desc.lower() if value_desc else reason.lower()
                # Classification keywords
                safety_kw = ["safety", "safe", "risk", "injury", "stress"]
                emotional_kw = ["confidence", "feel", "emotion", "comfort", "enjoy"]
                functional_kw = ["soften", "brace", "increase", "decrease", "bend", "pressure", "rhythm", "contact", "control"]
                measurement_kw = ["seconds", "minutes", "hours", "ft", "feet", "meters", "m", "degrees", "bpm", "kg", "lb", "%"]
                if any(k in vt_lower for k in safety_kw):
                    vtype = "Safety"
                elif any(k in vt_lower for k in emotional_kw):
                    vtype = "Emotional"
                elif any(k in vt_lower for k in functional_kw):
                    vtype = "Functional"
                elif any(k in vt_lower for k in measurement_kw):
                    vtype = "Measurement"
                else:
                    vtype = "Informational"
            protocol.append({
                "slug": action,
                "phrase": self._slug_to_phrase(action),
                "perceived_reason": reason,
                "value_created": value_desc,
                "value_type": vtype,
                "predecessor": predecessors.get(action),
                # placeholder for children which will be filled below
                "children": []
            })
        # Build a nested tree based on predecessor relationships.  We
        # create a mapping from slug to step dict for quick lookup.
        steps_by_slug = {step["slug"]: step for step in protocol}
        roots: List[Dict[str, Any]] = []
        for step in protocol:
            pred = step.get("predecessor")
            # Remove the predecessor field; it's no longer needed once we build the tree
            step_pred = step.pop("predecessor")  # remove key
            if pred and pred in steps_by_slug:
                steps_by_slug[pred]["children"].append(step)
            else:
                roots.append(step)
        # Derive value tags from unique value types across the protocol
        value_tags = sorted({step.get("value_type") for step in protocol if step.get("value_type")})
        return {
            "ultimate_promise": promise,
            "key_outcomes": key_outcomes,
            "protocol": roots,
            "value_tags": value_tags
        }
