"""
ontology_pipeline.__main__

This module makes the package executable via ``python -m ontology_pipeline``.
It simply delegates to the command‑line interface defined in
``ontology_pipeline.main``.  By providing this wrapper, users can run
the pipeline from any location without worrying about import paths or
module names.  It adheres to the Unix principle: the package itself
should be runnable as a script.
"""

from .main import main


if __name__ == "__main__":
    main()